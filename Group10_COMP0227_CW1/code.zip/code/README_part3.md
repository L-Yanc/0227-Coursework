# Part 3 — learned-depth integration

## Methods and configurations

The Reference supplies predicted depth as RGBD. E1 sets the initial map's scale
from median trusted network depths. B inserts learned-depth points only where
triangulation lacks parallax, while retaining existing geometric checks.
B50/B80/B100 vary the trusted gradient percentile; B80u10 restricts B to the first
ten keyframes. E1s50/E1s80 vary initial-scale trust; B80E1 combines both methods.

configs/part3/KITTI06_depth.yaml supplies KITTI factor 256. TUM/Replica use pinned
course settings with factors 5000/6553.5. CW1_METHOD, CW1_SIGMA_PCT and
CW1_DEPTH_UNTIL select the integration; CW1_PRED_DEPTH supplies associations.
The original Part 2 sampling implementation is retained in the combined diff.

## Commands

    python3 scripts/part3/generate_depth.py --pyslam /path/to/pyslam --datasets /data/tum_layout
    python3 scripts/part3/run_configurations.py --pyslam /path/to/pyslam --datasets /data/tum_layout
    python3 scripts/report/part3.py --out /external/report_assets
    python3 scripts/submission/import_results.py --part 3

The planners preview commands; --execute explicitly starts new experiments.
Scoring/pose-time/raw export tools remain in scripts/part3. Use their documented
positional CSV, dataset and output arguments from the raw-run working directory.

## Final evidence and report

inputs/part3.csv is the final 220-run export (41bde4c); inputs/part3 contains the
source runs/measures, summary and all pose-time proofs. Offset is 0 for 200 runs
and +2 for 20 batch-1 TUM Reference/true-RGBD runs. These corrected RPE values were
recomputed from archived original poses. Map keyframe IDs use offset 0.
Largest per-run median GT mismatch is 0.59 mm, individual rounded mismatch 2.56 mm,
and canonical TUM times differ from corrected times by up to 11.258 ms.

Table VI retains the batch-specific mono comparisons and >=95% KITTI tracking
filter; the CSV retains every run. Figure 1's original image is included; its
generator can use supplied TUM/GT when original selected-run JSONs are absent.
Original full logs/maps/poses for 160 runs and exact checkpoint hashes are not
bundled, so full independent historical rescoring is not claimed.

Hardware: skate-l/shark-l, i7-9800X @ 3.80 GHz, 30 GB RAM, CPU SLAM; depth maps made
once on RTX 4070 with DAV2 large metric indoor/outdoor from pySLAM models-depth.
Normalised IDs retain batch/configuration distinctions; original IDs remain in
source_run_id. See README.md for setup and common packaging.

## Batch comparisons

These supplied numerical summaries retain each method's matched baseline.

### fr3

| config | own mono | ATE SE(3) | ATE Sim(3) | s | RPE 1 s | map MAE | tracking ms | runs used |
|---|---|---|---|---|---|---|---|---|
| A/mono | - | 1.29 (1.242-1.313) | 0.02758 (0.0182-0.05023) | 2.669 (2.511-2.749) | 0.01239 (0.01129-0.01996) | 0.08246 (0.07583-0.1117) | 42.87 (39.68-58.5) | 10/10 |
| A/pseudo-rgbd | A/mono | 0.3752 (0.3127-0.4089) | 0.1724 (0.1412-0.2101) | 0.8613 (0.8542-0.8808) | 0.04217 (0.03779-0.06803) | 0.3194 (0.2608-0.3514) | 64.49 (51.53-81.63) | 10/10 |
| A/rgbd | A/mono | 0.009546 (0.008576-0.01117) | 0.00938 (0.008336-0.01113) | 1.001 (1-1.001) | 0.009182 (0.008414-0.009436) | 0.05054 (0.04716-0.05246) | 54.63 (46.32-90.18) | 10/10 |
| B100 | mono | 1.397 (1.376-1.432) | 0.02535 (0.01998-0.04197) | 3.096 (3.003-3.267) | 0.01798 (0.0134-0.02193) | 0.1035 (0.08734-0.1207) | 48.01 (38.82-49.8) | 5/5 |
| B50 | mono | 1.398 (1.337-1.706) | 0.02423 (0.01911-0.0556) | 3.102 (2.843-5.776) | 0.01575 (0.01414-0.06293) | 0.09032 (0.08308-0.115) | 51.82 (40.25-59.15) | 5/5 |
| B80 | mono | 1.481 (1.4-1.726) | 0.03891 (0.02235-1.603) | 3.437 (1.976-4.015) | 0.01821 (0.01615-0.1516) | 0.08906 (0.08091-0.6975) | 44.83 (40.67-51.59) | 5/5 |
| B80E1 | mono | 0.3366 (0.1671-0.4466) | 0.02369 (0.01656-0.05015) | 1.194 (1.087-1.274) | 0.0175 (0.01434-0.02841) | 0.08775 (0.08517-0.126) | 44.2 (43.85-45.83) | 5/5 |
| B80u10 | mono | 1.343 (1.335-1.37) | 0.02056 (0.01288-0.04282) | 2.866 (2.832-2.976) | 0.012 (0.01159-0.01254) | 0.08299 (0.0783-0.08578) | 43.42 (42.74-44.55) | 5/5 |
| E1 | mono | 0.05188 (0.04558-0.0996) | 0.01939 (0.01489-0.02374) | 0.9765 (0.955-0.9815) | 0.01201 (0.01166-0.01466) | 0.08017 (0.07727-0.0909) | 41.59 (40.11-52.76) | 5/5 |
| E1s50 | mono_x | 0.07882 (0.05428-0.1381) | 0.02749 (0.02178-0.03165) | 1.037 (1.025-1.07) | 0.016 (0.01417-0.02518) | 0.08831 (0.08367-0.141) | 44.88 (42.43-45.52) | 5/5 |
| E1s80 | mono_x | 0.02948 (0.02468-0.05082) | 0.02701 (0.01921-0.0505) | 0.9972 (0.9886-1.011) | 0.01435 (0.01235-0.06418) | 0.08602 (0.07823-0.1709) | 45.03 (44.59-46.2) | 5/5 |
| mono | - | 1.292 (1.262-1.367) | 0.02615 (0.02128-0.04483) | 2.677 (2.573-2.962) | 0.01344 (0.01249-0.0188) | 0.0875 (0.07793-0.0903) | 46.45 (39.65-54.03) | 5/5 |
| mono_x | - | 1.287 (1.263-1.361) | 0.02548 (0.01529-0.03351) | 2.658 (2.578-2.936) | 0.01333 (0.0116-0.01607) | 0.08838 (0.08357-0.0995) | 42.15 (41.14-50.81) | 5/5 |

### room0

| config | own mono | ATE SE(3) | ATE Sim(3) | s | RPE 1 s | map MAE | tracking ms | runs used |
|---|---|---|---|---|---|---|---|---|
| A/mono | - | 0.7347 (0.7318-0.7467) | 0.004768 (0.003708-0.006885) | 2.872 (2.851-2.963) | 0.004459 (0.003955-0.005912) | 0.0594 (0.05357-0.06244) | 69.53 (62.64-77.72) | 10/10 |
| A/pseudo-rgbd | A/mono | 0.4732 (0.467-0.4868) | 0.01139 (0.009992-0.0154) | 0.7044 (0.6985-0.7072) | 0.006807 (0.00638-0.007547) | 1.136 (1.098-1.18) | 81.11 (76.43-97.77) | 10/10 |
| A/rgbd | A/mono | 0.005938 (0.004555-0.006389) | 0.004498 (0.003715-0.006029) | 0.9973 (0.9957-0.9981) | 0.003534 (0.003277-0.003991) | 0.05351 (0.05248-0.05609) | 79.7 (67.2-82.18) | 10/10 |
| B100 | mono | 0.7657 (0.754-0.7732) | 0.004802 (0.004028-0.00499) | 3.118 (3.02-3.184) | 0.004409 (0.004227-0.004521) | 0.06177 (0.06-0.06759) | 66.64 (66.26-83.85) | 5/5 |
| B50 | mono | 0.7542 (0.7485-0.7585) | 0.005321 (0.003837-0.007567) | 3.021 (2.976-3.057) | 0.004435 (0.004084-0.005256) | 0.05999 (0.05838-0.0622) | 64.05 (62.09-67.67) | 5/5 |
| B80 | mono | 0.7723 (0.7604-0.7741) | 0.004688 (0.004072-0.006344) | 3.176 (3.073-3.192) | 0.004502 (0.004057-0.005416) | 0.06227 (0.05915-0.06518) | 68.76 (61.05-71.14) | 5/5 |
| B80E1 | mono_rest | 0.2812 (0.2607-0.3026) | 0.004279 (0.004076-0.005066) | 0.8003 (0.7884-0.8122) | 0.004489 (0.004109-0.004611) | 0.06071 (0.05762-0.06096) | 59.32 (58.66-59.77) | 5/5 |
| B80u10 | mono_rest | 0.7571 (0.7533-0.7646) | 0.004284 (0.003822-0.005911) | 3.045 (3.014-3.108) | 0.004243 (0.003961-0.004774) | 0.05697 (0.05481-0.05912) | 58.25 (57.84-59.66) | 5/5 |
| E1 | mono | 0.5391 (0.5343-0.5611) | 0.004007 (0.003747-0.004494) | 0.6765 (0.6676-0.6785) | 0.004229 (0.004078-0.00434) | 0.05837 (0.0572-0.06423) | 73.9 (59.37-85.23) | 5/5 |
| E1s50 | mono_x | 0.4165 (0.4109-0.4413) | 0.004458 (0.004113-0.005222) | 0.7302 (0.7187-0.7329) | 0.004498 (0.004081-0.004797) | 0.05845 (0.05616-0.05972) | 69.67 (63.48-79.03) | 5/5 |
| E1s80 | mono_x | 0.3961 (0.3917-0.4086) | 0.004943 (0.004129-0.007314) | 0.74 (0.734-0.7422) | 0.004436 (0.004233-0.004989) | 0.05996 (0.05306-0.06105) | 65.28 (62.42-96.02) | 5/5 |
| mono | - | 0.731 (0.7291-0.7354) | 0.004472 (0.003987-0.004817) | 2.845 (2.831-2.877) | 0.004376 (0.004158-0.004561) | 0.05558 (0.05431-0.06029) | 67.65 (62.84-101) | 5/5 |
| mono_rest | mono | 0.7335 (0.7305-0.7382) | 0.004495 (0.003812-0.004759) | 2.863 (2.841-2.897) | 0.0045 (0.003979-0.004532) | 0.05768 (0.05292-0.06211) | 59.36 (58.39-64.28) | 5/5 |
| mono_x | - | 0.7324 (0.7315-0.7338) | 0.004696 (0.004076-0.005114) | 2.855 (2.849-2.865) | 0.004338 (0.004121-0.004502) | 0.05998 (0.05933-0.06118) | 76.93 (61.39-88.13) | 5/5 |

### kitti

| config | own mono | ATE SE(3) | ATE Sim(3) | s | RPE 1 s | map MAE | tracking ms | runs used |
|---|---|---|---|---|---|---|---|---|
| A | mono_x | 23.35 (22.91-24.17) | 18.75 (17.81-19.67) | 0.9065 (0.9044-0.9074) | 0.603 (0.5598-0.8645) | nan (nan-nan) | 62.11 (60.23-62.16) | 3/5 |
| B100 | mono | 134.6 (134.5-134.9) | 15.03 (12.13-15.7) | 44.55 (42.96-49.82) | 1.32 (1.238-1.454) | nan (nan-nan) | 47.48 (47.24-48.39) | 5/5 |
| B50 | mono | 134.4 (134.1-134.7) | 13.57 (11.23-15.17) | 41.84 (38.19-45.64) | 1.274 (1.202-1.644) | nan (nan-nan) | 49.85 (49.52-50.33) | 4/5 |
| B80 | mono | 134.5 (133.6-134.8) | 15.37 (14.39-26.37) | 43.43 (33.06-47.13) | 1.368 (1.282-4.309) | nan (nan-nan) | 48.3 (47.29-52.25) | 4/5 |
| B80E1 | mono | 55.81 (53.7-60.57) | 10.18 (8.029-11.92) | 0.7133 (0.6975-0.7217) | 1.059 (0.9696-2.952) | nan (nan-nan) | 47.21 (45.67-48.59) | 5/5 |
| B80u10 | mono | 134.2 (134.1-134.4) | 13.2 (13.19-13.9) | 39.38 (38.28-41.82) | 1.202 (1.152-1.243) | nan (nan-nan) | 47.23 (47.17-48.26) | 3/5 |
| E1 | mono | 66.66 (50.08-97.58) | 19.23 (12.3-23.34) | 0.6786 (0.5883-0.7385) | 2.689 (1.072-3.077) | nan (nan-nan) | 43.4 (42.34-44.96) | 5/5 |
| E1s50 | mono_x | 142.1 (138.9-148.5) | 25.09 (24.36-25.33) | 0.4918 (0.4807-0.4976) | 2.618 (2.52-3.751) | nan (nan-nan) | 52.09 (45.83-61.65) | 3/5 |
| E1s80 | mono_x | 108.8 (82.17-144.1) | 21.66 (7.976-31.73) | 0.5626 (0.4883-0.6269) | 2.968 (0.8272-4.611) | nan (nan-nan) | 61.4 (46.65-66.13) | 3/5 |
| mono | - | 131.8 (131.6-132.3) | 11.69 (10.26-15.13) | 23.25 (22.34-25.37) | 1.027 (1.017-2.985) | nan (nan-nan) | 43.49 (43.23-44.63) | 4/5 |
| mono_x | - | 131.7 (131.3-131.9) | 14.15 (11.62-16.09) | 23.09 (21.32-23.87) | 1.415 (1.051-3.855) | nan (nan-nan) | 48.79 (46.09-72.33) | 5/5 |
